import axios from 'axios'

const apiFilmes = axios.create({
    baseURL: 'https://api.themoviedb.org/3/',
    headers: {
        'content-type': 'application/json;charset=utf-8',
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI0MzAxZTNjYTA4OTAyZmQ1ZDJmNTQ1ODRiYjdkYjhiYyIsInN1YiI6IjYyNTU4MDBlNjA4MmViMDA0ZmRmZTYyMyIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.jqdoWr9FuNWfYZ5ng23GDuNgSgYYa46D1EXOCHDGtNE'
    }
})

export default apiFilmes